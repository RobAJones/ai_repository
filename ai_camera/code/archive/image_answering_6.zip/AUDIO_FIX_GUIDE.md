# Audio Screeching Fix Guide

## Problem: Audible "screeches" during TTS playback

## Root Causes & Solutions:

### 1. **I2S Configuration Conflict** ✅ FIXED
- The same I2S peripheral was being used for both microphone input and speaker output
- **Solution**: Added delays between switching I2S modes
- **Code changes**: Added `delay(100)` before STT and TTS operations

### 2. **TTS Model Quality** ✅ FIXED
- Higher quality models (tts-1-hd) can cause buffer issues on ESP32
- **Solution**: Using standard `tts-1` model
- **Code changes**: 
  ```cpp
  tts.setModel("tts-1");  // Standard quality
  tts.setVoice("alloy");  // Clear voice
  tts.setSpeed(1.0);      // Normal speed
  ```

### 3. **Sample Rate Mismatch** (Check if issues persist)
- Recording at 16kHz but playback may expect different rate
- **Test different voices**: alloy, echo, fable, onyx, nova, shimmer
- **Try in code**:
  ```cpp
  tts.setVoice("echo");  // or nova, shimmer, etc.
  ```

### 4. **Buffer Underrun** (Check if issues persist)
- Audio buffer not keeping up with playback
- **Solution**: Added delay after TTS completes
- **Code changes**: `delay(500)` after playback

## If Screeching Persists:

### Option A: Change TTS Voice
Edit the `chatInit()` function and try different voices:
```cpp
tts.setVoice("nova");   // Female, warm
tts.setVoice("shimmer"); // Female, soft
tts.setVoice("echo");   // Male, clear
tts.setVoice("fable");  // Male, expressive
tts.setVoice("onyx");   // Male, deep
```

### Option B: Adjust Playback Speed
Slower speed may reduce artifacts:
```cpp
tts.setSpeed(0.9);  // Slightly slower
```

### Option C: Use Different Output Method
The OpenAI library's built-in playback may have issues. Consider:

1. **Save to SD card first**, then play:
   - Get TTS audio as buffer
   - Save to SD card
   - Play from SD card with proper I2S setup

2. **Use external I2S DAC/amplifier**:
   - Better audio quality
   - Separate from microphone input
   - Example: MAX98357A I2S amplifier

### Option D: Check Hardware
1. **Speaker connection**: Ensure proper wiring
2. **Power supply**: Audio artifacts often from insufficient power
3. **Ground loops**: Make sure all grounds are connected properly
4. **Interference**: Keep speaker wires away from camera cables

## Testing Audio Quality

After uploading the fixed code, test with:
1. Simple prompt: "What do you see?"
2. Listen for:
   - ✅ Clear speech at normal speed
   - ✅ No static/crackling
   - ✅ No high-pitched screeches
   - ❌ If still screeching, try Option A-D above

## Hardware Specs (ESP32-S3)
- Microphone Input: PDM via I2S (GPIO 38/39)
- Audio Output: Check your board schematic
  - May need external DAC/amplifier
  - Built-in DAC pins: GPIO17, GPIO18
  - I2S output recommended for better quality

## Debug Commands
Add to Serial Monitor to see what's happening:
```cpp
Serial.println("[TTS] Format: " + tts.getFormat());
Serial.println("[TTS] Voice: " + tts.getVoice());
Serial.printf("[TTS] Speed: %.2f\n", tts.getSpeed());
```

## Next Steps if Issues Continue

1. **Test TTS independently**: 
   - Comment out recording/vision parts
   - Just test TTS playback
   - Helps isolate if it's TTS-specific or I2S conflict

2. **Check OpenAI library version**:
   - Update to latest version
   - Check GitHub issues for audio problems

3. **Alternative approach**:
   - Use web browser for audio playback
   - Send TTS audio URL to browser
   - Play through computer speakers instead

Let me know which solution works!
