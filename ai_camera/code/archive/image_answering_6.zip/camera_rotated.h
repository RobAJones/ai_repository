#include "esp_camera.h"
#include "soc/soc.h"
#include "soc/rtc_cntl_reg.h"
#include <Arduino.h>

// OV2640 camera module pins (CAMERA_MODEL_AI_THINKER)
#define PWDN_GPIO_NUM -1
#define RESET_GPIO_NUM -1
#define XCLK_GPIO_NUM 5
#define SIOD_GPIO_NUM 8
#define SIOC_GPIO_NUM 9
#define Y9_GPIO_NUM 4
#define Y8_GPIO_NUM 6
#define Y7_GPIO_NUM 7
#define Y6_GPIO_NUM 14
#define Y5_GPIO_NUM 17
#define Y4_GPIO_NUM 21
#define Y3_GPIO_NUM 18
#define Y2_GPIO_NUM 16
#define VSYNC_GPIO_NUM 1
#define HREF_GPIO_NUM 2
#define PCLK_GPIO_NUM 15

void initCamera()
{
  // Disable brownout detector to prevent resets
  WRITE_PERI_REG(RTC_CNTL_BROWN_OUT_REG, 0);
  
  camera_config_t config;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer = LEDC_TIMER_0;
  config.pin_d0 = Y2_GPIO_NUM;
  config.pin_d1 = Y3_GPIO_NUM;
  config.pin_d2 = Y4_GPIO_NUM;
  config.pin_d3 = Y5_GPIO_NUM;
  config.pin_d4 = Y6_GPIO_NUM;
  config.pin_d5 = Y7_GPIO_NUM;
  config.pin_d6 = Y8_GPIO_NUM;
  config.pin_d7 = Y9_GPIO_NUM;
  config.pin_xclk = XCLK_GPIO_NUM;
  config.pin_pclk = PCLK_GPIO_NUM;
  config.pin_vsync = VSYNC_GPIO_NUM;
  config.pin_href = HREF_GPIO_NUM;
  config.pin_sccb_sda = SIOD_GPIO_NUM;
  config.pin_sccb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn = PWDN_GPIO_NUM;
  config.pin_reset = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;
  config.pixel_format = PIXFORMAT_JPEG;
  config.grab_mode = CAMERA_GRAB_LATEST;
  
  // CRITICAL: Configure for PSRAM to prevent FB-OVF
  if (psramFound()) {
    Serial.println("PSRAM found! Using PSRAM for frame buffers");
    config.fb_location = CAMERA_FB_IN_PSRAM;
    config.frame_size = FRAMESIZE_VGA;  // 640x480 - good balance
    config.jpeg_quality = 12;  // Lower = better quality (10-63 range)
    config.fb_count = 2;  // Double buffering
  } else {
    Serial.println("WARNING: PSRAM not found! Using DRAM (limited)");
    config.fb_location = CAMERA_FB_IN_DRAM;
    config.frame_size = FRAMESIZE_QVGA;  // 320x240 - smaller for DRAM
    config.jpeg_quality = 15;
    config.fb_count = 1;  // Single buffer to save memory
  }

  // Initialize camera
  esp_err_t err = esp_camera_init(&config);
  if (err != ESP_OK) {
    Serial.printf("Camera init failed with error 0x%x\n", err);
    Serial.println("Possible causes:");
    Serial.println("1. PSRAM not enabled in Arduino IDE");
    Serial.println("2. Camera module connection issues");
    Serial.println("3. Power supply insufficient");
    return;
  }

  Serial.println("Camera initialized successfully!");

  // Get sensor for additional configuration
  sensor_t *s = esp_camera_sensor_get();
  if (s == NULL) {
    Serial.println("Failed to get camera sensor");
    return;
  }

  // *** 180 DEGREE ROTATION ***
  // This rotates the image 180 degrees (upside down correction)
  s->set_hmirror(s, 1);  // Horizontal mirror (flip left-right)
  s->set_vflip(s, 1);    // Vertical flip (flip top-bottom)
  Serial.println("Camera rotated 180 degrees");
  
  // Additional settings for better performance
  s->set_framesize(s, config.frame_size);
  s->set_quality(s, config.jpeg_quality);
  
  // Optimize for streaming (reduce motion blur, improve color)
  s->set_whitebal(s, 1);       // Enable white balance
  s->set_awb_gain(s, 1);       // Enable auto white balance gain
  s->set_wb_mode(s, 0);        // Auto white balance mode
  s->set_exposure_ctrl(s, 1);  // Enable auto exposure
  s->set_aec2(s, 0);           // Disable AEC sensor
  s->set_ae_level(s, 0);       // Auto exposure level
  s->set_aec_value(s, 300);    // Manual exposure value
  s->set_gain_ctrl(s, 1);      // Enable gain control
  s->set_agc_gain(s, 0);       // Auto gain control
  s->set_gainceiling(s, (gainceiling_t)0);  // Gain ceiling
  s->set_bpc(s, 0);            // Disable black pixel correction
  s->set_wpc(s, 1);            // Enable white pixel correction
  s->set_raw_gma(s, 1);        // Enable raw gamma
  s->set_lenc(s, 1);           // Enable lens correction
  s->set_dcw(s, 1);            // Enable downsize
  s->set_colorbar(s, 0);       // Disable color bar test pattern
  
  Serial.printf("Camera configured: %dx%d, Quality: %d, FB Count: %d, FB Location: %s\n",
                s->status.framesize == FRAMESIZE_VGA ? 640 : 320,
                s->status.framesize == FRAMESIZE_VGA ? 480 : 240,
                config.jpeg_quality,
                config.fb_count,
                config.fb_location == CAMERA_FB_IN_PSRAM ? "PSRAM" : "DRAM");
}
